<?php
// Text
$_['text_title'] = '<span style="background: url(image/payment/concordpay.svg) 0 0 no-repeat !important;"><img src="image/payment/concordpay.png" alt="ConcordPay" title="ConcordPay"></span>&nbsp;Оплата Visa, Mastercard, GooglePay, ApplePay';
$_['text_payment_by_card'] = 'Оплата карткою на сайті';
?>
